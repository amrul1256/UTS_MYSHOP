import 'package:flutter/material.dart';
import '../models/product.dart';
import 'product_detail_page.dart';


class ProductListPage extends StatelessWidget {
final String categoryName;
final List<Product> products;


const ProductListPage({
super.key,
required this.categoryName,
required this.products,
});


@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(title: Text(categoryName)),
body: GridView.builder(
padding: const EdgeInsets.all(12),
itemCount: products.length,
gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
crossAxisCount: 2,
childAspectRatio: 3 / 4,
mainAxisSpacing: 12,
crossAxisSpacing: 12,
),
itemBuilder: (context, index) {
final product = products[index];
return GestureDetector(
onTap: () {
Navigator.push(
context,
MaterialPageRoute(
builder: (_) => ProductDetailPage(product: product),
),
);
},
child: Card(
// **MODIFIKASI 1: Pewarnaan Card**
color: Colors.lightBlue.shade50,
elevation: 5,
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
child: Padding(
  padding: const EdgeInsets.all(8.0),
  child: Column(
    mainAxisAlignment: MainAxisAlignment.spaceAround, // Menyesuaikan tata letak
    children: [
      // **MODIFIKASI 2: Menggunakan icon/emoji produk**
      Text(
        product.icon,
        style: const TextStyle(fontSize: 48),
      ),
      const SizedBox(height: 10),
      Text(
        product.name,
        textAlign: TextAlign.center,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 16,
        ),
      ),
      const SizedBox(height: 5),
      // **MODIFIKASI 3: Menambahkan Harga**
      Text(
        "Rp ${product.price}",
        style: TextStyle(
          fontSize: 14,
          color: Colors.blue.shade700,
          fontWeight: FontWeight.w600,
        ),
      ),
    ],
  ),
),
),
);
},
),
);
}
}