import 'package:flutter/material.dart';
import '../models/category.dart';
import 'product_list_page.dart';

class HomePage extends StatelessWidget {
  final List<Category> categories;

  const HomePage({super.key, required this.categories});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("MyShop Mini"),
        centerTitle: true,
      ),

      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];

          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              title: Text(
                category.name,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ProductListPage(
                      categoryName: category.name,
                      products: category.products,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
