import 'package:flutter/material.dart';
import '../models/product.dart';


class ProductDetailPage extends StatelessWidget {
final Product product;


const ProductDetailPage({super.key, required this.product});


@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(
  title: Text(product.name),
  backgroundColor: Colors.blueAccent, // Menambahkan warna pada AppBar
),
body: Center(
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
// **MODIFIKASI 1: Menggunakan icon/emoji produk**
Text(
  product.icon,
  style: const TextStyle(fontSize: 120),
),
const SizedBox(height: 20),
Text(
product.name,
style: const TextStyle(
  fontSize: 30,
  fontWeight: FontWeight.bold,
  color: Colors.black87,
),
),
const SizedBox(height: 10),
// **MODIFIKASI 2: Menambahkan pewarnaan harga**
Container(
  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
  decoration: BoxDecoration(
    color: Colors.green.shade100,
    borderRadius: BorderRadius.circular(20),
    border: Border.all(color: Colors.green.shade400),
  ),
  child: Text(
    "Rp ${product.price}",
    style: TextStyle(
      fontSize: 24,
      color: Colors.green.shade700,
      fontWeight: FontWeight.bold,
    ),
  ),
),
],
),
),
);
}
}