import 'package:flutter/material.dart';
import 'data/dummy_data.dart';
import 'pages/home_page.dart';
import 'theme/app_theme.dart';


void main() {
runApp(const MyShopMiniApp());
}


class MyShopMiniApp extends StatelessWidget {
const MyShopMiniApp({super.key});


@override
Widget build(BuildContext context) {
return MaterialApp(
title: 'MyShop Mini',
debugShowCheckedModeBanner: false,
theme: AppTheme.lightTheme,
home: HomePage(categories: dummyCategories),
);
}
}