import 'package:flutter/material.dart';


class AppTheme {
static final lightTheme = ThemeData(
primarySwatch: Colors.blue,
appBarTheme: const AppBarTheme(elevation: 2),
);
}