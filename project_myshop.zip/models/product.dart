class Product {
  final String name;
  final String icon;
  final int price;

  Product({
    required this.name,
    required this.icon,
    required this.price,
  });
}
