import 'package:flutter/material.dart';
import '../models/product.dart';


class ProductCard extends StatelessWidget {
final Product product;
final VoidCallback onTap;


const ProductCard({super.key, required this.product, required this.onTap});


@override
Widget build(BuildContext context) {
return GestureDetector(
onTap: onTap,
child: Card(
elevation: 3,
child: Column(
mainAxisAlignment: MainAxisAlignment.center,
children: [
const Icon(Icons.shopping_bag, size: 48),
const SizedBox(height: 10),
Text(product.name),
],
),
),
);
}
}