import '../models/category.dart';
import '../models/product.dart';

final List<Category> dummyCategories = [
  Category(
    name: "Makanan",
    products: [
      Product(name: "Roti", icon: "🍞", price: 10000),
      Product(name: "Nasi Goreng", icon: "🍛", price: 15000),
      Product(name: "Burger", icon: "🍔", price: 20000),
    ],
  ),

  Category(
    name: "Minuman",
    products: [
      Product(name: "Air Mineral", icon: "💧", price: 5000),
      Product(name: "Jus Jeruk", icon: "🧃", price: 12000),
      Product(name: "Kopi", icon: "☕", price: 10000),
    ],
  ),

  Category(
    name: "Elektronik",
    products: [
      Product(name: "Headset", icon: "🎧", price: 80000),
      Product(name: "Keyboard", icon: "⌨️", price: 150000),
      Product(name: "Mouse", icon: "🖱️", price: 70000),
    ],
  ),
];
